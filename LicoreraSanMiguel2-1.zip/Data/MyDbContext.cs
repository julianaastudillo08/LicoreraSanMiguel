public class MyDbContext : DbContext
{
    public string ConnectionString { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Cliente>().HasKey(c => c.Id);
        modelBuilder.Entity<Producto>().HasKey(p => p.Id);
        modelBuilder.Entity<Compra>().HasKey(c => c.Id);
        modelBuilder.Entity<DetalleCompra>().HasKey(dc => dc.Id);
        modelBuilder.Entity<Factura>().HasKey(f => f.Id);
        modelBuilder.Entity<DetalleVenta>().HasKey(dv => dv.Id);
    }
}