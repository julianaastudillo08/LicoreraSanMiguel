using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;

public class DbContext
{
    private readonly IDbConnection _dbConnection;

    public DbContext(string connectionString)
    {
var dbContext = new MyDbContext(connectionString);
      }

    public IEnumerable<T> Query<T>(string sql, object param = null)
    {
        return _dbConnection.Query<T>(sql, param);
    }

    public int Execute(string sql, object param = null)
    {
        return _dbConnection.Execute(sql, param);
    }
}
