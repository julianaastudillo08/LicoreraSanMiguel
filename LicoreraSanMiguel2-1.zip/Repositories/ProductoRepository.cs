using System.Collections.Generic;
using Dapper;

public class ProductoRepository
{
    private readonly DbContext _dbContext;

    public ProductoRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Producto> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<Producto>(connection, "SELECT * FROM Productos");
    }

    public Producto Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<Producto>(connection, "SELECT * FROM Productos WHERE Id = @Id", new { Id = id });
    }

    public void AddProducto(Producto producto)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Productos (Nombre, Descripcion, Precio, Disponibilidad) VALUES (@Nombre, @Descripcion, @Precio, @Disponibilidad)", producto);
    }

    public void UpdateProducto(Producto producto)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE Productos SET Nombre = @Nombre, Descripcion = @Descripcion, Precio = @Precio, Disponibilidad = @Disponibilidad WHERE Id = @Id", producto);
    }

    public void DeleteProducto(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Productos WHERE Id = @Id", new { Id = id });
    }
}
