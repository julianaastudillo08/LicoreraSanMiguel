using System.Collections.Generic;
using Dapper;

public class StockRepository
{
    private readonly DbContext _dbContext;

    public StockRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Stock> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<Stock>(connection, "SELECT * FROM Stock");
    }

    public Stock Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<Stock>(connection, "SELECT * FROM Stock WHERE Id = @Id", new { Id = id });
    }

    public void AddStock(Stock stock)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Stock (ProductoId, Cantidad) VALUES (@ProductoId, @Cantidad)", stock);
    }

    public void UpdateStock(Stock stock)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE Stock SET ProductoId = @ProductoId, Cantidad = @Cantidad WHERE Id = @Id", stock);
    }

    public void DeleteStock(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Stock WHERE Id = @Id", new { Id = id });
    }
}
