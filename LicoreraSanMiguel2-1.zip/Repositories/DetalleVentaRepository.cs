using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Dapper;

public class DetalleVentaRepository
{
    private readonly DbContext _dbContext;

    public DetalleVentaRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<DetalleVenta> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<DetalleVenta>(connection, "SELECT * FROM DetalleVentas");
    }

    public DetalleVenta Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<DetalleVenta>(connection, "SELECT * FROM DetalleVentas WHERE Id = @Id", new { Id = id });
    }

    public void AddDetalleVenta(DetalleVenta detalleVenta)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO DetalleVentas (VentaId, ProductoId, Cantidad, PrecioUnitario) VALUES (@VentaId, @ProductoId, @Cantidad, @PrecioUnitario)", detalleVenta);
    }

    public void UpdateDetalleVenta(DetalleVenta detalleVenta)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE DetalleVentas SET VentaId = @VentaId, ProductoId = @ProductoId, Cantidad = @Cantidad, PrecioUnitario = @PrecioUnitario WHERE Id = @Id", detalleVenta);
    }

    public void DeleteDetalleVenta(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM DetalleVentas WHERE Id = @Id", new { Id = id });
    }
}
