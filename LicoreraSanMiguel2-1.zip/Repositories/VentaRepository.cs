using System.Collections.Generic;
using Dapper;

public class VentaRepository
{
    private readonly DbContext _dbContext;

    public VentaRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Venta> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<Venta>(connection, "SELECT * FROM Ventas");
    }

    public Venta Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<Venta>(connection, "SELECT * FROM Ventas WHERE Id = @Id", new { Id = id });
    }

    public void AddVenta(Venta venta)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Ventas (ClienteId, ProductoId, Cantidad, PrecioTotal) VALUES (@ClienteId, @ProductoId, @Cantidad, @PrecioTotal)", venta);
    }

    public void UpdateVenta(Venta venta)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE Ventas SET ClienteId = @ClienteId, ProductoId = @ProductoId, Cantidad = @Cantidad, PrecioTotal = @PrecioTotal WHERE Id = @Id", venta);
    }

    public void DeleteVenta(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Ventas WHERE Id = @Id", new { Id = id });
    }
}
