using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Dapper;

public class FacturaRepository
{
    private readonly DbContext _dbContext;

    public FacturaRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Factura> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<Factura>(connection, "SELECT * FROM Facturas");
    }

    public Factura Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<Factura>(connection, "SELECT * FROM Facturas WHERE Id = @Id", new { Id = id });
    }

    public void AddFactura(Factura factura)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Facturas (ClienteId, Fecha, MontoTotal) VALUES (@ClienteId, @Fecha, @MontoTotal)", factura);
    }

    public void UpdateFactura(Factura factura)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE Facturas SET ClienteId = @ClienteId, Fecha = @Fecha, MontoTotal = @MontoTotal WHERE Id = @Id", factura);
    }

    public void DeleteFactura(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Facturas WHERE Id = @Id", new { Id = id });
    }
}
