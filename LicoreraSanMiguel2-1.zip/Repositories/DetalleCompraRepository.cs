using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Dapper;


public class DetalleCompraRepository
{
    private readonly DbContext _dbContext;

    public DetalleCompraRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<DetalleCompra> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<DetalleCompra>(connection, "SELECT * FROM DetalleCompras");
    }

    public DetalleCompra Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<DetalleCompra>(connection, "SELECT * FROM DetalleCompras WHERE Id = @Id", new { Id = id });
    }

    public void AddDetalleCompra(DetalleCompra detalleCompra)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO DetalleCompras (CompraId, ProductoId, Cantidad, PrecioUnitario) VALUES (@CompraId, @ProductoId, @Cantidad, @PrecioUnitario)", detalleCompra);
    }

    public void UpdateDetalleCompra(DetalleCompra detalleCompra)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE DetalleCompras SET CompraId = @CompraId, ProductoId = @ProductoId, Cantidad = @Cantidad, PrecioUnitario = @PrecioUnitario WHERE Id = @Id", detalleCompra);
    }

    public void DeleteDetalleCompra(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM DetalleCompras WHERE Id = @Id", new { Id = id });
    }
}
