using System;
using System.Collections.Generic;
using Dapper;

public class DetalleFacturaRepository
{
    private readonly DbContext _dbContext;

    public DetalleFacturaRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<DetalleFactura> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<DetalleFactura>(connection, "SELECT * FROM DetalleFacturas");
    }

    public DetalleFactura Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<DetalleFactura>(connection, "SELECT * FROM DetalleFacturas WHERE Id = @Id", new { Id = id });
    }

    public void AddDetalleFactura(DetalleFactura detalleFactura)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO DetalleFacturas (FacturaId, ProductoId, Cantidad, PrecioUnitario, PrecioTotal) VALUES (@FacturaId, @ProductoId, @Cantidad, @PrecioUnitario, @PrecioTotal)", detalleFactura);
    }

    public void UpdateDetalleFactura(DetalleFactura detalleFactura)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE DetalleFacturas SET FacturaId = @FacturaId, ProductoId = @ProductoId, Cantidad = @Cantidad, PrecioUnitario = @PrecioUnitario, PrecioTotal = @PrecioTotal WHERE Id = @Id", detalleFactura);
    }

    public void DeleteDetalleFactura(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM DetalleFacturas WHERE Id = @Id", new { Id = id });
    }
}
