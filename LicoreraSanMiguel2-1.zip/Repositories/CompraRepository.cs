using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Dapper;

public class CompraRepository
{
    private readonly DbContext _dbContext;

    public CompraRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Compra> GetAll()
    {
        var connection = _dbContext.Database.Connection;
        return SqlMapper.Query<Compra>(connection, "SELECT * FROM Compras");
    }

    public Compra Get(int id)
    {
        var connection = _dbContext.Database.Connection;
        return SqlMapper.QuerySingleOrDefault<Compra>(connection, "SELECT * FROM Compras WHERE Id = @Id", new { Id = id });
    }

    public void AddCompra(Compra compra)
    {
        var connection = _dbContext.Database.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Compras (ProveedorId, Fecha, MontoTotal) VALUES (@ProveedorId, @Fecha, @MontoTotal)", compra);
    }

    public void UpdateCompra(Compra compra)
    {
        var connection = _dbContext.Database.Connection;
        SqlMapper.Execute(connection, "UPDATE Compras SET ProveedorId = @ProveedorId, Fecha = @Fecha, MontoTotal = @MontoTotal WHERE Id = @Id", compra);
    }

    public void DeleteCompra(int id)
    {
        var connection = _dbContext.Database.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Compras WHERE Id = @Id", new { Id = id });
    }
}