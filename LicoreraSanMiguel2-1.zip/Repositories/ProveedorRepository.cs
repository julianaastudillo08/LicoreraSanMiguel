using System.Collections.Generic;
using Dapper;

public class ProveedorRepository
{
    private readonly DbContext _dbContext;

    public ProveedorRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Proveedor> GetAll()
    {
        var connection = _dbContext.Connection;
        return SqlMapper.Query<Proveedor>(connection, "SELECT * FROM Proveedores");
    }

    public Proveedor Get(int id)
    {
        var connection = _dbContext.Connection;
        return SqlMapper.QuerySingleOrDefault<Proveedor>(connection, "SELECT * FROM Proveedores WHERE Id = @Id", new { Id = id });
    }

    public void AddProveedor(Proveedor proveedor)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Proveedores (Nombre, Telefono, Empresa, CorreoElectronico) VALUES (@Nombre, @Telefono, @Empresa, @CorreoElectronico)", proveedor);
    }

    public void UpdateProveedor(Proveedor proveedor)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "UPDATE Proveedores SET Nombre = @Nombre, Telefono = @Telefono, Empresa = @Empresa, CorreoElectronico = @CorreoElectronico WHERE Id = @Id", proveedor);
    }

    public void DeleteProveedor(int id)
    {
        var connection = _dbContext.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Proveedores WHERE Id = @Id", new { Id = id });
    }
}
