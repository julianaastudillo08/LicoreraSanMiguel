using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Dapper;

public class ClienteRepository
{
    private readonly DbContext _dbContext;

    public ClienteRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IEnumerable<Cliente> GetAll()
    {
        var connection = _dbContext.Database.Connection;
        return SqlMapper.Query<Cliente>(connection, "SELECT * FROM Clientes");
    }

    public Cliente Get(int id)
    {
        var connection = _dbContext.Database.Connection;
        return SqlMapper.QuerySingleOrDefault<Cliente>(connection, "SELECT * FROM Clientes WHERE Id = @Id", new { Id = id });
    }

    public void AddCliente(Cliente cliente)
    {
        var connection = _dbContext.Database.Connection;
        SqlMapper.Execute(connection, "INSERT INTO Clientes (Nombre, Direccion, Telefono) VALUES (@Nombre, @Direccion, @Telefono)", cliente);
    }

    public void UpdateCliente(Cliente cliente)
    {
        var connection = _dbContext.Database.Connection;
        SqlMapper.Execute(connection, "UPDATE Clientes SET Nombre = @Nombre, Direccion = @Direccion, Telefono = @Telefono WHERE Id = @Id", cliente);
    }

    public void DeleteCliente(int id)
    {
        var connection = _dbContext.Database.Connection;
        SqlMapper.Execute(connection, "DELETE FROM Clientes WHERE Id = @Id", new { Id = id });
    }
}
