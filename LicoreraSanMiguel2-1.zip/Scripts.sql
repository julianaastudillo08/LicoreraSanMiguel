-- Script para crear las tablas
CREATE TABLE IF NOT EXISTS Clientes (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT,
    Direccion TEXT,
    Telefono TEXT
);

CREATE TABLE IF NOT EXISTS Productos (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT,
    Descripcion TEXT,
    Precio DECIMAL,
    Disponibilidad INTEGER
);

CREATE TABLE IF NOT EXISTS Ventas (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ClienteId INTEGER,
    ProductoId INTEGER,
    Cantidad INTEGER,
    PrecioTotal DECIMAL,
    FOREIGN KEY(ClienteId) REFERENCES Clientes(Id),
    FOREIGN KEY(ProductoId) REFERENCES Productos(Id)
);

CREATE TABLE IF NOT EXISTS Stock (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ProductoId INTEGER,
    Cantidad INTEGER,
    FOREIGN KEY(ProductoId) REFERENCES Productos(Id)
);

CREATE TABLE IF NOT EXISTS Proveedores (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT,
    Telefono TEXT,
    Empresa TEXT,
    CorreoElectronico TEXT
);

CREATE TABLE IF NOT EXISTS Compras (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ProveedorId INTEGER,
    Fecha DATETIME,
    MontoTotal DECIMAL,
    FOREIGN KEY(ProveedorId) REFERENCES Proveedores(Id)
);

-- Script para crear relaciones
-- Las relaciones se crearon al definir las claves foráneas en las tablas
-- No es necesario agregar relaciones adicionales en este caso, ya están especificadas en la creación de las tablas
