using System;
using System.Collections.Generic;
using Dapper;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        string connectionString = "Data Source=licorera.db;Version=3;";
        var dbContext = new DbContext(connectionString);

        // Operaciones de Clientes
        var clienteRepository = new ClienteRepository(dbContext);

        // Obtener todos los clientes
        var clientes = clienteRepository.GetAll();

        Console.WriteLine("Clientes:");
        foreach (var cliente in clientes)
        {
            Console.WriteLine($"ID: {cliente.Id}, Nombre: {cliente.Nombre}, Dirección: {cliente.Direccion}, Teléfono: {cliente.Telefono}");
        }

        // Agregar un nuevo cliente
        Cliente nuevoCliente = new Cliente
        {
            Nombre = "Nuevo Cliente",
            Direccion = "Dirección del Nuevo Cliente",
            Telefono = "123456789"
        };
        clienteRepository.AddCliente(nuevoCliente);

        // Obtener un cliente por ID
        Cliente clienteById = clienteRepository.Get(1);
        if (clienteById != null)
        {
            Console.WriteLine($"\nCliente ID 1: Nombre - {clienteById.Nombre}, Dirección - {clienteById.Direccion}, Teléfono - {clienteById.Telefono}");
        }

        // Actualizar un cliente
        clienteById.Nombre = "Cliente Actualizado";
        clienteRepository.UpdateCliente(clienteById);

        // Eliminar un cliente por ID
        clienteRepository.DeleteCliente(2);

        // Operaciones de Productos
        var productoRepository = new ProductoRepository(dbContext);

        // Obtener todos los productos
        var productos = productoRepository.GetAll();

        Console.WriteLine("\nProductos:");
        foreach (var producto in productos)
        {
            Console.WriteLine($"ID: {producto.Id}, Nombre: {producto.Nombre}, Descripción: {producto.Descripcion}, Precio: {producto.Precio}, Disponibilidad: {producto.Disponibilidad}");
        }

        // Agregar un nuevo producto
        Producto nuevoProducto = new Producto
        {
            Nombre = "Nuevo Producto",
            Descripcion = "Descripción del Nuevo Producto",
            Precio = 10.99m,
            Disponibilidad = 100
        };
        productoRepository.AddProducto(nuevoProducto);

        // Actualizar un producto
        Producto productoById = productoRepository.Get(1);
        if (productoById != null)
        {
            productoById.Precio = 9.99m;
            productoRepository.UpdateProducto(productoById);
        }

        // Eliminar un producto por ID
        productoRepository.DeleteProducto(2);

        // Operaciones de Proveedores
        var proveedorRepository = new ProveedorRepository(dbContext);

        // Obtener todos los proveedores
        var proveedores = proveedorRepository.GetAll();

        Console.WriteLine("\nProveedores:");
        foreach (var proveedor in proveedores)
        {
            Console.WriteLine($"ID: {proveedor.Id}, Nombre: {proveedor.Nombre}, Teléfono: {proveedor.Telefono}, Empresa: {proveedor.Empresa}, Correo Electrónico: {proveedor.CorreoElectronico}");
        }

        // Agregar un nuevo proveedor
        Proveedor nuevoProveedor = new Proveedor
        {
            Nombre = "Nuevo Proveedor",
            Telefono = "987654321",
            Empresa = "Empresa del Nuevo Proveedor",
            CorreoElectronico = "nuevo@proveedor.com"
        };
        proveedorRepository.AddProveedor(nuevoProveedor);

        // Actualizar un proveedor
        Proveedor proveedorById = proveedorRepository.Get(1);
        if (proveedorById != null)
        {
            proveedorById.Empresa = "Nueva Empresa";
            proveedorRepository.UpdateProveedor(proveedorById);
        }

        // Eliminar un proveedor por ID
        proveedorRepository.DeleteProveedor(2);

        // Operaciones de Compras
        var compraRepository = new CompraRepository(dbContext);

        // Obtener todas las compras
        var compras = compraRepository.GetAll();

        Console.WriteLine("\nCompras:");
        foreach (var compra in compras)
        {
            Console.WriteLine($"ID: {compra.Id}, Proveedor ID: {compra.ProveedorId}, Fecha: {compra.Fecha}, Monto Total: {compra.MontoTotal}");
        }

        // Agregar una nueva compra
        Compra nuevaCompra = new Compra
        {
            ProveedorId = 1, // Asigna un ID de proveedor existente
            Fecha = DateTime.Now,
            MontoTotal = 50.00m
        };
        compraRepository.AddCompra(nuevaCompra);

        // Actualizar una compra
        Compra compraById = compraRepository.Get(1);
        if (compraById != null)
        {
            compraById.MontoTotal = 60.00m;
            compraRepository.UpdateCompra(compraById);
        }

        // Eliminar una compra por ID
        compraRepository.DeleteCompra(2);

        // Operaciones de Stocks
        var stockRepository = new StockRepository(dbContext);

        // Obtener todos los stocks
        var stocks = stockRepository.GetAll();

        Console.WriteLine("\nStocks:");
        foreach (var stock in stocks)
        {
            Console.WriteLine($"ID: {stock.Id}, Producto ID: {stock.ProductoId}, Cantidad: {stock.Cantidad}");
        }

        // Agregar un nuevo stock
        Stock nuevoStock = new Stock
        {
            ProductoId = 1, // Asigna un ID de producto existente
            Cantidad = 50
        };
        stockRepository.AddStock(nuevoStock);

        // Actualizar un stock
        Stock stockById = stockRepository.Get(1);
        if (stockById != null)
        {
            stockById.Cantidad = 60;
            stockRepository.UpdateStock(stockById);
        }

        // Eliminar un stock por ID
        stockRepository.DeleteStock(2);

        // Operaciones de Ventas
        var ventaRepository = new VentaRepository(dbContext);

        // Obtener todas las ventas
        var ventas = ventaRepository.GetAll();

        Console.WriteLine("\nVentas:");
        foreach (var venta in ventas)
        {
            Console.WriteLine($"ID: {venta.Id}, Cliente ID: {venta.ClienteId}, Producto ID: {venta.ProductoId}, Cantidad: {venta.Cantidad}, Precio Total: {venta.PrecioTotal}");
        }

        // Agregar una nueva venta
        Venta nuevaVenta = new Venta
        {
            ClienteId = 1, // Asigna un ID de cliente existente
            ProductoId = 1, // Asigna un ID de producto existente
            Cantidad = 2,
            PrecioTotal = 20.00m
        };
        ventaRepository.AddVenta(nuevaVenta);

        // Actualizar una venta
        Venta ventaById = ventaRepository.Get(1);
        if (ventaById != null)
        {
            ventaById.PrecioTotal = 25.00m;
            ventaRepository.UpdateVenta(ventaById);
        }

        // Eliminar una venta por ID
        ventaRepository.DeleteVenta(2);

      // Operaciones de Facturas
var facturaRepository = new FacturaRepository(dbContext);

// Obtener todas las facturas
var facturas = facturaRepository.GetAll();

Console.WriteLine("\nFacturas:");
foreach (var factura in facturas)
{
    Console.WriteLine($"ID: {factura.Id}, Cliente ID: {factura.ClienteId}, Fecha: {factura.Fecha}, Monto Total: {factura.MontoTotal}");
}

// Agregar una nueva factura
Factura nuevaFactura = new Factura
{
    ClienteId = 1, // Asigna un ID de cliente existente
    Fecha = DateTime.Now,
    MontoTotal = 100.00m
};
facturaRepository.AddFactura(nuevaFactura);

// Actualizar una factura
Factura facturaById = facturaRepository.Get(1);
if (facturaById != null)
{
    facturaById.MontoTotal = 120.00m;
    facturaRepository.UpdateFactura(facturaById);
}

// Eliminar una factura por ID
facturaRepository.DeleteFactura(2);

// Operaciones de Detalles de Factura
var detalleFacturaRepository = new DetalleFacturaRepository(dbContext);

// Obtener todos los detalles de factura
var detallesFactura = detalleFacturaRepository.GetAll();

Console.WriteLine("\nDetalles de Factura:");
foreach (var detalleFactura in detallesFactura)
{
    Console.WriteLine($"ID: {detalleFactura.Id}, Factura ID: {detalleFactura.FacturaId}, Producto ID: {detalleFactura.ProductoId}, Cantidad: {detalleFactura.Cantidad}, Precio Unitario: {detalleFactura.PrecioUnitario}");
}

// Agregar un nuevo detalle de factura
DetalleFactura nuevoDetalleFactura = new DetalleFactura
{
    FacturaId = 1, // Asigna un ID de factura existente
    ProductoId = 1, // Asigna un ID de producto existente
    Cantidad = 5,
    PrecioUnitario = 15.00m
};
detalleFacturaRepository.AddDetalleFactura(nuevoDetalleFactura);

// Actualizar un detalle de factura
DetalleFactura detalleFacturaById = detalleFacturaRepository.Get(1);
if (detalleFacturaById != null)
{
    detalleFacturaById.PrecioUnitario = 18.00m;
    detalleFacturaRepository.UpdateDetalleFactura(detalleFacturaById);
}

// Eliminar un detalle de factura por ID
detalleFacturaRepository.DeleteDetalleFactura(2);

// Operaciones de Detalles de Compra
var detalleCompraRepository = new DetalleCompraRepository(dbContext);

// Obtener todos los detalles de compra
var detallesCompra = detalleCompraRepository.GetAll();

Console.WriteLine("\nDetalles de Compra:");
foreach (var detalleCompra in detallesCompra)
{
    Console.WriteLine($"ID: {detalleCompra.Id}, Compra ID: {detalleCompra.CompraId}, Producto ID: {detalleCompra.ProductoId}, Cantidad: {detalleCompra.Cantidad}, Precio Unitario: {detalleCompra.PrecioUnitario}");
}

// Agregar un nuevo detalle de compra
DetalleCompra nuevoDetalleCompra = new DetalleCompra
{
    CompraId = 1, // Asigna un ID de compra existente
    ProductoId = 1, // Asigna un ID de producto existente
    Cantidad = 5,
    PrecioUnitario = 15.00m
};
detalleCompraRepository.AddDetalleCompra(nuevoDetalleCompra);

// Actualizar un detalle de compra
DetalleCompra detalleCompraById = detalleCompraRepository.Get(1);
if (detalleCompraById != null)
{
    detalleCompraById.PrecioUnitario = 18.00m;
    detalleCompraRepository.UpdateDetalleCompra(detalleCompraById);
}

// Eliminar un detalle de compra por ID
detalleCompraRepository.DeleteDetalleCompra(2);

// Operaciones de Detalles de Venta
var detalleVentaRepository = new DetalleVentaRepository(dbContext);

// Obtener todos los detalles de venta
var detallesVenta = detalleVentaRepository.GetAll();

Console.WriteLine("\nDetalles de Venta:");
foreach (var detalleVenta in detallesVenta)
{
    Console.WriteLine($"ID: {detalleVenta.Id}, Venta ID: {detalleVenta.VentaId}, Producto ID: {detalleVenta.ProductoId}, Cantidad: {detalleVenta.Cantidad}, Precio Unitario: {detalleVenta.PrecioUnitario}");
}

// Agregar un nuevo detalle de venta
DetalleVenta nuevoDetalleVenta = new DetalleVenta
{
    VentaId = 1, // Asigna un ID de venta existente
    ProductoId = 1, // Asigna un ID de producto existente
    Cantidad = 5,
    PrecioUnitario = 15.00m
};
detalleVentaRepository.AddDetalleVenta(nuevoDetalleVenta);

// Actualizar un detalle de venta
DetalleVenta detalleVentaById = detalleVentaRepository.Get(1);
if (detalleVentaById != null)
{
    detalleVentaById.PrecioUnitario = 18.00m;
    detalleVentaRepository.UpdateDetalleVenta(detalleVentaById);
}

// Eliminar un detalle de venta por ID
detalleVentaRepository.DeleteDetalleVenta(2);
    }
}