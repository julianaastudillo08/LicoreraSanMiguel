public class Proveedor
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Telefono { get; set; }
    public string Empresa { get; set; }
    public string CorreoElectronico { get; set; }
}