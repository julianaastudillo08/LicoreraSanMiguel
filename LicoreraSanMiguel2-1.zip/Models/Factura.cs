using System;
public class Factura
{
    public int Id { get; set; }
    public int ClienteId { get; set; }
    public DateTime Fecha { get; set; }
    public decimal MontoTotal { get; set; }
}
