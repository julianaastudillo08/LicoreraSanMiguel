using System;

public class Compra
{
    public int Id { get; set; }
    public int ProveedorId { get; set; }
    public DateTime Fecha { get; set; }
    public decimal MontoTotal { get; set; }
}